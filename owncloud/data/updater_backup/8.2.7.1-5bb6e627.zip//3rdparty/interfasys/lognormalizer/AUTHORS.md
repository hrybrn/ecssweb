# Authors

## Current

* Olivier Paroz: <dev-lognormalizer@interfasys.ch>

## Original author

* Jordi Boggiano <j.boggiano@seld.be>

